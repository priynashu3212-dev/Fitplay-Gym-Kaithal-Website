import { type ReactNode, useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  ArrowDownRight,
  ArrowRight,
  Check,
  Clock3,
  Instagram,
  MapPin,
  Menu,
  Phone,
  Play,
  X,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

const navItems = [
  { href: '/', label: 'Home' },
  { href: '/about', label: 'The gym' },
  { href: '/training', label: 'Training' },
  { href: '/memberships', label: 'Memberships' },
  { href: '/contact', label: 'Contact' },
];

const trainingOffers = [
  ['01', 'Strength floor', 'Free weights, racks, cables and room to find your form.'],
  ['02', 'Personal training', 'One-to-one guidance that meets you where you are.'],
  ['03', 'Functional fitness', 'Move better, work harder, feel ready for real life.'],
  ['04', 'Beginner foundations', 'A friendly start, simple plans and zero guesswork.'],
];

function useReveal() {
  useEffect(() => {
    const nodes = document.querySelectorAll<HTMLElement>('.reveal');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);
}

function SiteHeader({ onBookVisit }: { onBookVisit: () => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 28);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);
  const handleBookVisit = () => {
    closeMenu();
    onBookVisit();
  };

  return (
    <header className={`topbar ${scrolled ? 'scrolled' : ''}`} data-testid="header-main">
      <div className="container-wide flex h-[72px] items-center justify-between">
        <Link href="/" className="brand-mark display flex items-center gap-2 bg-[var(--acid)] px-3 py-2 text-[1.5rem] font-extrabold leading-none" data-testid="link-brand">FIT<span className="text-[var(--ember)]">/</span>PLAY</Link>
        <nav className="nav-desktop flex items-center gap-6" aria-label="Primary navigation">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href} className={`nav-link eyebrow ${location === item.href ? 'active' : ''}`} data-testid={`link-nav-${item.label.toLowerCase().replace(' ', '-')}`}>{item.label}</Link>
          ))}
          <button onClick={handleBookVisit} className="button-primary !px-4 !py-3" data-testid="button-nav-visit">Book a visit <ArrowRight size={15} /></button>
        </nav>
        <button className="mobile-menu" onClick={() => setMenuOpen((open) => !open)} aria-label={menuOpen ? 'Close menu' : 'Open menu'} aria-expanded={menuOpen} data-testid="button-mobile-menu">
          {menuOpen ? <X size={19} /> : <Menu size={19} />}
        </button>
      </div>
      {menuOpen && (
        <nav className="mobile-links" aria-label="Mobile navigation">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href} onClick={closeMenu} className={`eyebrow ${location === item.href ? 'active' : ''}`}>{item.label}</Link>
          ))}
          <button onClick={handleBookVisit} className="button-primary" data-testid="button-mobile-visit">Book a visit <ArrowRight size={15} /></button>
        </nav>
      )}
    </header>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container-wide">
        <div className="footer-grid">
          <div>
            <div className="display footer-logo">FIT<span className="text-[var(--acid)]">/</span>PLAY</div>
            <p className="mt-6 max-w-[250px] text-sm leading-6 text-[rgba(245,241,232,.55)]">A stronger everyday, built in Kaithal.</p>
          </div>
          <div>
            <p className="footer-label">Find us</p>
            <a href="https://maps.google.com/?q=Fitplay+Gym+Kaithal" target="_blank" rel="noreferrer" className="flex items-start gap-2" data-testid="link-footer-map"><MapPin size={15} className="mt-0.5 text-[var(--acid)]" />Near City Centre,<br />Kaithal, Haryana</a>
            <a href="tel:+919876543210" className="mt-4 flex items-center gap-2" data-testid="link-footer-phone"><Phone size={14} className="text-[var(--acid)]" />+91 98765 43210</a>
          </div>
          <div>
            <p className="footer-label">Hours</p>
            <p className="text-sm leading-7 text-[rgba(245,241,232,.68)]"><span className="text-[var(--paper)]">Mon — Sat</span><br />6:00 AM — 10:00 PM<br /><span className="text-[var(--paper)]">Sunday</span><br />7:00 AM — 1:00 PM</p>
            <a href="https://www.instagram.com/" target="_blank" rel="noreferrer" className="mt-5 flex items-center gap-2" data-testid="link-footer-instagram"><Instagram size={15} className="text-[var(--acid)]" /> @fitplaykaithal</a>
          </div>
        </div>
        <div className="footer-bottom"><span>© 2024 Fitplay Gym Kaithal</span><span className="flex items-center gap-2"><Clock3 size={13} /> Train with intent.</span></div>
      </div>
    </footer>
  );
}

function BookingModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [submitted, setSubmitted] = useState(false);
  useEffect(() => {
    if (open) setSubmitted(false);
  }, [open]);
  if (!open) return null;

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="visit-title" data-testid="modal-visit">
      <div className="modal">
        <button className="close-button" onClick={onClose} aria-label="Close visit form" data-testid="button-close-visit"><X size={18} /></button>
        {!submitted ? (
          <form onSubmit={(event) => { event.preventDefault(); setSubmitted(true); }}>
            <p className="eyebrow text-[var(--ember)]">No pressure / just a hello</p>
            <h2 id="visit-title" className="display mt-4">Come see<br />the floor.</h2>
            <p className="mt-4 text-sm leading-6 opacity-70">Leave your details and we’ll have someone from the crew reach out to set up your first look.</p>
            <label className="form-label" htmlFor="visit-name">Your name</label>
            <input id="visit-name" required placeholder="What should we call you?" data-testid="input-visit-name" />
            <label className="form-label" htmlFor="visit-phone">Phone number</label>
            <input id="visit-phone" required type="tel" placeholder="+91" data-testid="input-visit-phone" />
            <label className="form-label" htmlFor="visit-goal">What brings you in?</label>
            <select id="visit-goal" defaultValue="strength" data-testid="select-visit-goal"><option value="strength">Build strength</option><option value="fitness">Get fitter</option><option value="beginner">Start from scratch</option><option value="training">Personal training</option></select>
            <button type="submit" className="button-dark mt-7 w-full" data-testid="button-submit-visit">Send it through <ArrowRight size={16} /></button>
          </form>
        ) : (
          <div className="py-8"><p className="eyebrow text-[var(--ember)]">You're on the list</p><h2 className="display mt-5">See you<br />on the floor.</h2><p className="mt-5 text-sm leading-7 opacity-70">Thanks for reaching out. The Fitplay crew will call you soon to arrange a good time.</p><button className="button-dark mt-7" onClick={onClose} data-testid="button-finish-visit">Done <Check size={16} /></button></div>
        )}
      </div>
    </div>
  );
}

function SiteLayout({ children }: { children: ReactNode }) {
  const [modalOpen, setModalOpen] = useState(false);
  return (
    <div className="fitplay-page">
      <SiteHeader onBookVisit={() => setModalOpen(true)} />
      {children}
      <Footer />
      <BookingModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </div>
  );
}

function IntroOverlay({ onFinish }: { onFinish: () => void }) {
  return (
    <div className="video-intro" role="dialog" aria-modal="true" aria-label="Fitplay Gym intro">
      <video className="video-intro-media" autoPlay muted playsInline onEnded={onFinish}>
        <source src="/assets/fitplay-opening.mp4" type="video/mp4" />
      </video>
      <div className="video-intro-shade" />
      <div className="video-intro-content">
        <div className="display video-intro-logo">FIT<span>/</span>PLAY</div>
        <p className="eyebrow">Kaithal's training ground</p>
        <div className="intro-progress" aria-hidden="true"><span /></div>
        <button className="video-intro-skip" onClick={onFinish}><Play size={13} fill="currentColor" /> Enter Fitplay</button>
      </div>
    </div>
  );
}

function Home() {
  useReveal();
  const [introVisible, setIntroVisible] = useState(true);
  const finishIntro = () => {
    window.sessionStorage.setItem('fitplay-intro-seen', 'true');
    setIntroVisible(false);
  };

  useEffect(() => {
    if (window.sessionStorage.getItem('fitplay-intro-seen')) setIntroVisible(false);
  }, []);

  return (
    <SiteLayout>
      {introVisible && <IntroOverlay onFinish={finishIntro} />}
      <main id="top">
        <section className="hero grain" aria-labelledby="hero-title">
          <video className="hero-video" autoPlay muted loop playsInline aria-hidden="true"><source src="/assets/fitplay-opening.mp4" type="video/mp4" /></video>
          <div className="container-wide hero-content">
            <p className="eyebrow reveal" style={{ color: 'var(--acid)' }}>Kaithal's training ground / Est. 2017</p>
            <h1 id="hero-title" className="display hero-title reveal delay-1">Show up.<br /><em>Get stronger.</em></h1>
            <div className="hero-meta reveal delay-2">
              <p className="hero-copy">A serious gym for everyday athletes. Build strength, sharpen your energy and find your people at Fitplay Gym Kaithal.</p>
              <Link className="arrow-link" href="/about" data-testid="link-hero-explore">Explore Fitplay <ArrowDownRight size={18} /></Link>
            </div>
          </div>
        </section>
        <div className="marquee" aria-label="Fitplay values"><div className="marquee-track"><span>Train with intent</span><i className="dot" /><span>Kaithal, Haryana</span><i className="dot" /><span>No shortcuts</span><i className="dot" /><span>Built together</span><i className="dot" /><span>Train with intent</span><i className="dot" /><span>Kaithal, Haryana</span><i className="dot" /><span>No shortcuts</span><i className="dot" /><span>Built together</span><i className="dot" /></div></div>

        <section className="section" aria-labelledby="home-gym-title">
          <div className="container-wide">
            <div className="intro-grid">
              <div className="reveal"><p className="eyebrow mb-5 text-[var(--ember)]">01 / The gym</p><p className="body-copy">Not a room full of machines. A place with a pulse. Fitplay is where Kaithal comes to move with purpose.</p></div>
              <div className="reveal delay-1"><h2 id="home-gym-title" className="display section-title">Make your<br /><span className="text-[var(--ember)]">move.</span></h2><p className="section-lede mt-8">Come for the equipment. Stay for the energy. Leave knowing you gave the day everything.</p><Link className="button-dark mt-8" href="/about">Meet the gym <ArrowRight size={16} /></Link></div>
            </div>
            <div className="stat-band mt-24 reveal delay-2" aria-label="Fitplay gym facts"><div className="stat"><div className="display stat-number">7+</div><div className="stat-label">Years in Kaithal</div></div><div className="stat"><div className="display stat-number">6AM</div><div className="stat-label">Doors open early</div></div><div className="stat"><div className="display stat-number">1</div><div className="stat-label">Crew that has your back</div></div><div className="stat"><div className="display stat-number">∞</div><div className="stat-label">Reasons to return</div></div></div>
          </div>
        </section>

        <section className="dark-panel section" aria-labelledby="home-training-title">
          <div className="container-wide">
            <div className="offer-wrap">
              <div className="reveal"><p className="eyebrow mb-5 text-[var(--acid)]">02 / Training</p><h2 id="home-training-title" className="display section-title">Train<br />your way.</h2><p className="mt-8 max-w-[300px] text-sm leading-7 text-[rgba(245,241,232,.6)]">From your first squat to your strongest set, every session has a place here.</p><Link className="button-primary mt-8" href="/training">See training <ArrowRight size={16} /></Link></div>
              <OfferList className="reveal delay-1" />
            </div>
          </div>
        </section>

        <section className="acid-panel cta-panel grain" aria-labelledby="home-cta-title"><div className="container-wide"><p className="eyebrow reveal">03 / Your first rep</p><h2 id="home-cta-title" className="display cta-title mt-8 reveal delay-1">Ready to<br /><span className="text-[var(--ember)]">start?</span></h2><p className="cta-copy reveal delay-2">Walk in for a look, ask us anything and get a feel for the floor.</p><Link href="/contact" className="button-dark reveal delay-3">Plan your visit <ArrowRight size={16} /></Link></div></section>
      </main>
    </SiteLayout>
  );
}

function OfferList({ className = '' }: { className?: string }) {
  return (
    <div className={`offer-list ${className}`}>
      {trainingOffers.map(([index, name, description]) => (
        <div className="offer-item" key={index}><span className="offer-index">{index}</span><div><div className="offer-name">{name}</div><div className="offer-desc">{description}</div></div><ArrowRight size={19} /></div>
      ))}
    </div>
  );
}

function PageHero({ eyebrow, title, accent, copy }: { eyebrow: string; title: string; accent: string; copy: string }) {
  return (
    <section className="page-hero dark-panel grain">
      <div className="container-wide page-hero-content">
        <p className="eyebrow text-[var(--acid)] reveal">{eyebrow}</p>
        <h1 className="display page-title reveal delay-1">{title}<br /><span className="text-[var(--acid)]">{accent}</span></h1>
        <p className="page-hero-copy reveal delay-2">{copy}</p>
      </div>
    </section>
  );
}

function AboutPage() {
  useReveal();
  return (
    <SiteLayout>
      <main>
        <PageHero eyebrow="01 / The gym" title="Built for" accent="everyday athletes." copy="Fitplay is Kaithal's training ground for people who want to feel stronger, move better and keep showing up." />
        <section className="section"><div className="container-wide"><div className="intro-grid"><div className="reveal"><p className="eyebrow mb-5 text-[var(--ember)]">The Fitplay idea</p><p className="body-copy">We started with a simple belief: a gym should feel like a place you want to return to. The right equipment matters. So does a good coach, a familiar face and a floor that makes you want to get one more rep.</p></div><div className="reveal delay-1"><p className="pull-quote">Come as you are. Train with intent. Leave a little stronger.</p></div></div><div className="stat-band mt-24 reveal delay-2" aria-label="Fitplay gym facts"><div className="stat"><div className="display stat-number">2017</div><div className="stat-label">Founded in Kaithal</div></div><div className="stat"><div className="display stat-number">6AM</div><div className="stat-label">Doors open early</div></div><div className="stat"><div className="display stat-number">100%</div><div className="stat-label">No ego energy</div></div><div className="stat"><div className="display stat-number">∞</div><div className="stat-label">Reasons to return</div></div></div></div></section>
        <section className="section dark-panel"><div className="container-wide"><div className="flex flex-wrap items-end justify-between gap-8"><div className="reveal"><p className="eyebrow mb-5 text-[var(--acid)]">02 / The crew</p><h2 className="display section-title">Good people<br /><span className="text-[var(--acid)]">get results.</span></h2></div><p className="body-copy body-copy-dark reveal delay-1">Our coaches know the difference between pushing you and showing up for you. Expect both.</p></div><TeamGrid /></div></section>
      </main>
    </SiteLayout>
  );
}

function TeamGrid() {
  return (
    <div className="team-layout mt-14"><article className="coach-card reveal"><span className="coach-role">Founder / Coach</span><h3 className="display coach-name">Ravi<br />Kumar</h3><p className="coach-note">“Your best session is the one you make it to.”</p></article><div className="grid gap-[18px]"><article className="coach-card acid reveal delay-1"><span className="coach-role">Strength / Conditioning</span><h3 className="display coach-name">Simran<br />Kaur</h3><p className="coach-note">Form first. Then we add the fire.</p></article><article className="coach-card ember reveal delay-2"><span className="coach-role">Front desk / Good energy</span><h3 className="display coach-name">The<br />Fitplay crew</h3></article></div></div>
  );
}

function TrainingPage() {
  useReveal();
  return (
    <SiteLayout>
      <main>
        <PageHero eyebrow="02 / Training" title="Train" accent="your way." copy="From your first squat to your strongest set, every session has a place here. No intimidation. Just good coaching and better consistency." />
        <section className="dark-panel section pt-0"><div className="container-wide"><OfferList className="reveal" /><div className="class-grid"><article className="class-card tall acid-panel reveal delay-1"><span className="class-tag">Session focus / 01</span><div><h2 className="display class-name">Build<br />the base</h2><p className="mt-5">Strong movement patterns. Steady progress. The kind of work that stays with you.</p></div></article><div className="grid gap-[18px]"><article className="class-card orange-panel reveal delay-2"><span className="class-tag">Session focus / 02</span><div><h2 className="display class-name">Raise<br />the bar</h2><p className="mt-4">Push past the comfortable edge with smart, coached intensity.</p></div></article><article className="class-card reveal delay-3"><span className="class-tag">Session focus / 03</span><div><h2 className="display class-name">Keep<br />showing up</h2><p className="mt-4">The real transformation is built between the big moments.</p></div></article></div></div></div></section>
        <section className="section"><div className="container-wide"><div className="testimonial reveal"><div className="quote-mark">“</div><div><p className="quote-text">I joined for the equipment. I kept coming because everyone knows your name.</p><p className="quote-by">— Ankit, Fitplay member since 2021</p></div></div></div></section>
      </main>
    </SiteLayout>
  );
}

function MembershipsPage() {
  useReveal();
  return (
    <SiteLayout>
      <main>
        <PageHero eyebrow="03 / Memberships" title="Choose" accent="your pace." copy="Straightforward memberships. Everything you need to make training part of your week, not another thing to overthink." />
        <section className="dark-panel section pt-0"><div className="container-wide"><div className="pricing-grid pricing-grid-page"><PriceCard eyebrow="Start here" name="Monthly" amount="₹1,200" period="per month / no fuss" items={['Full gym access', 'Equipment orientation', 'Community floor']} /><PriceCard featured eyebrow="Best rhythm" name="Quarterly" amount="₹3,000" period="three months / keep momentum" items={['Full gym access', 'Goal-setting check-in', 'Save ₹600 overall']} /><PriceCard eyebrow="Go all in" name="Annual" amount="₹9,600" period="twelve months / your year" items={['Full gym access', 'Quarterly progress review', 'Save ₹4,800 overall']} /></div><div className="membership-note reveal"><p className="eyebrow text-[var(--acid)]">Included with every plan</p><p>Friendly floor support, a clean training space, and a community that will notice when you show up.</p></div></div></section>
      </main>
    </SiteLayout>
  );
}

function PriceCard({ eyebrow, name, amount, period, items, featured = false }: { eyebrow: string; name: string; amount: string; period: string; items: string[]; featured?: boolean }) {
  return (
    <article className={`price-card reveal ${featured ? 'featured' : ''}`}><span className={`eyebrow ${featured ? '' : 'text-[var(--acid)]'}`}>{eyebrow}</span><h2 className="price-name mt-5">{name}</h2><div className="price-amount">{amount}</div><div className="price-period">{period}</div><ul className="price-list">{items.map((item) => <li key={item}><Check size={16} /> {item}</li>)}</ul></article>
  );
}

function ContactPage() {
  useReveal();
  return (
    <SiteLayout>
      <main>
        <PageHero eyebrow="04 / Contact" title="Make the" accent="first move." copy="Come in for a look, ask us anything and get a feel for the floor. Your first step does not need to be perfect. It just needs to happen." />
        <section className="section"><div className="container-wide"><div className="contact-grid"><div className="reveal"><p className="eyebrow mb-5 text-[var(--ember)]">Find the floor</p><h2 className="display section-title">See you<br /><span className="text-[var(--ember)]">at Fitplay.</span></h2><p className="body-copy mt-8">Near City Centre,<br />Kaithal, Haryana</p><a href="https://maps.google.com/?q=Fitplay+Gym+Kaithal" target="_blank" rel="noreferrer" className="button-dark mt-8">Open in Maps <MapPin size={16} /></a></div><div className="contact-details reveal delay-1"><div><p className="footer-label text-[var(--ember)]">Call</p><a className="contact-link" href="tel:+919876543210">+91 98765 43210</a></div><div><p className="footer-label text-[var(--ember)]">Hours</p><p className="contact-copy">Monday — Saturday<br />6:00 AM — 10:00 PM<br /><br />Sunday<br />7:00 AM — 1:00 PM</p></div><div><p className="footer-label text-[var(--ember)]">Social</p><a className="contact-link" href="https://www.instagram.com/" target="_blank" rel="noreferrer">@fitplaykaithal <Instagram size={18} /></a></div></div></div></div></section>
        <section className="acid-panel cta-panel grain"><div className="container-wide"><p className="eyebrow reveal">Your first rep</p><h2 className="display cta-title mt-8 reveal delay-1">Ready to<br /><span className="text-[var(--ember)]">start?</span></h2><p className="cta-copy reveal delay-2">Book a visit and the crew will help you find the right place to begin.</p></div></section>
      </main>
    </SiteLayout>
  );
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route path="/about" component={AboutPage} /><Route path="/training" component={TrainingPage} /><Route path="/memberships" component={MembershipsPage} /><Route path="/contact" component={ContactPage} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;